<script>
  import "../app.postcss";
  import "../global.css";

  let isPageLoaded = true;
</script>
<slot />