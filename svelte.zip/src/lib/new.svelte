<script>
    import { toggleNew } from './stores';
</script>

{#if $toggleNew}
  <div
    class=" z-50 fixed top-0 left-0 flex h-full min-h-screen w-full items-center justify-center bg-gray-500 bg-opacity-90 px-4 py-5">
    <div
      class="w-full max-w-[570px] rounded-[20px] bg-white py-12 px-8 text-center md:py-[60px] md:px-[70px]">
      <div>
        <h3 class="text-dark pb-2 text-xl font-bold sm:text-2xl">
            Your Message Sent Successfully
        </h3>
        </div>
      <span class="bg-primary mx-auto mb-6 inline-block h-1 w-[90px] rounded"></span>
      <p class="text-body-color mb-10 text-base leading-relaxed">
        Lorem Ipsum is simply dummy text of the printing and typesetting
        industry. Lorem Ipsum has been the industry's standard dummy text ever
        since
      </p>
      <div class="-mx-3 flex flex-wrap">
        <div class="w-1/2 px-3">
          <button
            class="text-dark block w-full rounded-lg border border-[#E9EDF9] p-3 text-center text-base font-medium transition hover:border-red-600 hover:bg-red-600 hover:text-white">
            Cancel
          </button>
        </div>
        <div class="w-1/2 px-3">
          <button
            class="bg-primary border-primary block w-full rounded-lg border p-3 text-center text-base font-medium text-white transition hover:bg-opacity-90">
            View Details
          </button>
        </div>
      </div>
    </div>
  </div>
{/if}